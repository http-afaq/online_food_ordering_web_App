import { createContext } from "react";

export const CartUpdateContext=createContext(null);